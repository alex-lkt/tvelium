<?php
/* 
Template Name: Все новости
*/
global $current_user;
?>
<?php
    if ( !is_user_logged_in() ) {
        header( 'Location: /' );
    } 
?>

<?php get_header();?>

<section class="main">
    <div class="main-wrapper">

    <?php
    foreach( $current_user->roles as $role ) {
        switch ($role) {
            case 'administrator':
                include "include/main-asside-admin.php";
                include "include/main-content-news.php";
                break;
            case 'author':
                include "include/main-asside-copyriter.php";
                include "include/main-content-news.php";
                break;
            case 'subscriber':
                include "include/main-asside-user.php";
                include "include/main-content-news.php";
                break;
        }
    }
    ?>

    </div>
</section>

<?php get_footer(); ?>