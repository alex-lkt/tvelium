<header class="header-homepage">
    <div class="container">
        <div class="header-homepage__logo">
            <a class="homepage-logo__link" href="/">
                <img class="homepage-logo" src="<?php echo get_template_directory_uri() ?>/assets/images/logo-1.svg" alt="Tvelium.ru">
            </a>
        </div>
    </div>
</header>