<?php get_header();?>

<h1 style="text-align:center; margin: 100px">page 404</h1>

<?php get_footer(); ?>